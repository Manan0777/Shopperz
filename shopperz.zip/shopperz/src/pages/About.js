import React from 'react';

function About() {
  /* States and Variables start */
  /* States and Variables end */

  /* Initializers start */
  /* Initializers end */

  /* Utils start */
  /* Utils end */

  /* Handlers start */
  /* Handlers end */

  /* UI start */
  /* UI end */

  return (
    <div
      className="class"
    >
      <h1>This is the About page</h1> 
    </div>
  );
}

export default About;
